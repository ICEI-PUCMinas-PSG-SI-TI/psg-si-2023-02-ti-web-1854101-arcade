document.addEventListener("DOMContentLoaded", function () {
    const listaUsuarios = document.getElementById("listaUsuarios");
    const cadastrarButton = document.getElementById("cadastrarButton");
    
    // Verifica se já existem usuários no Local Storage
    let usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];

    cadastrarButton.addEventListener("click", function (e) {
        e.preventDefault();

        const username = document.getElementById("usuario").value;
        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;
        const data = document.getElementById("data").value;

        // Adicionar o novo usuário à lista
        const novoUsuario = {
            username: username,
            email: email,
            password: password,
            data: data,
        }
        if(username.length == 0 || email.length == 0 || password.length == 0 || data.length == 0){
            alert("campo vazio");
        }

            usuarios.push(novoUsuario);

            // Armazenar a lista atualizada no Local Storage
            localStorage.setItem("listaUsuarios", JSON.stringify(usuarios));
            // Informação de cadastro
            alert("Cadastrado com sucesso!")


        // Limpar os campos do formulário
        document.getElementById("usuario").value = "";
        document.getElementById("email").value = "";
        document.getElementById("password").value = "";
        document.getElementById("data").value = "";
    });
});
